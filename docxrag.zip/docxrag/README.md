# docxrag — parser DOCX orienté RAG

Parser DOCX en **lxml pur** (Pillow optionnel) : ordre de lecture exact, titres non standards
(DOC convertis, « Level 1 », hiérarchie par mise en forme), tableaux fusionnés, images avec
métadonnées, sommaire, légendes, notes. Sortie **compatible `DoclingDocument` 1.10.0**,
métadonnées RAG en sidecar `x_docx`, chunking hiérarchique intégré, description d'images par
modèle multimodal **désactivée par défaut** et découplée (`docxrag.vision`).

```bash
pip install lxml pillow            # docling-core facultatif (validation / interop)
python -m docxrag rapport.docx -o rapport.json --markdown rapport.md --chunks chunks.jsonl
python -m docxrag rapport.docx -o r.json --describe anthropic:claude-sonnet-4-6 --vision-cache cache.jsonl
python -m pytest tests -q          # 56 tests
python bench/bench.py 100          # micro-benchmark
```

```python
from docxrag import parse_docx, to_docling_dict, chunk_document, ChunkerConfig
res = parse_docx("rapport.docx")
doc_json = to_docling_dict(res.model)                  # DoclingDocument + sidecar x_docx
chunks = chunk_document(res.model, ChunkerConfig(max_tokens=512))
```

Modules : `ooxml` (paquet OPC sécurisé) → `styles` (styles/numérotation) → `extract` (blocs plats,
ordre de lecture, anti-doublons) → `classify` (rôles, titres a→h + garde-fous) → `assemble`
(arbre, sections, légendes, sommaire) → `serialize` (JSON Docling / Markdown) → `chunking`.
`images` gère binaires, hash et tailles ; `vision` l'enrichissement optionnel.
