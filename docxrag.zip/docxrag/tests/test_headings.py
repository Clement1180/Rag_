"""Détection des titres standards et non standards."""
from conftest import texts
from docxbuilder import p, run

BODY = "Ceci est un paragraphe de corps de texte suffisamment long pour établir la taille de référence."


def heads(model):
    return [(t.text, t.level, t.meta.get("heading_source")) for t in texts(model, "section_header")]


def test_builtin_heading_styles_and_hierarchy(make):
    res, _ = make(p("Titre du doc", style="Title") + p("Intro", style="Heading1") + p(BODY)
                  + p("Détail", style="Heading2") + p(BODY) + p("Suite", style="Heading1") + p(BODY))
    m = res.model
    assert heads(m) == [("Intro", 1, "outline_level"), ("Détail", 2, "outline_level"), ("Suite", 1, "outline_level")]
    title = texts(m, "title")[0]
    intro = m.resolve(title.children[0])
    assert intro.text == "Intro"
    assert m.resolve(intro.children[1]).text == "Détail"       # Détail est fils d'Intro
    suite = [t for t in m.texts if t.text == "Suite"][0]
    assert suite.parent == title.self_ref                        # Suite remonte au niveau 1


def test_level_n_style_names_without_outline(make):
    res, _ = make(p("Chapitre A", style="Level1") + p(BODY) + p("Section A.1", style="Level2") + p(BODY))
    assert heads(res.model) == [("Chapitre A", 1, "style_name"), ("Section A.1", 2, "style_name")]


def test_custom_style_inherits_outline_level(make):
    res, _ = make(p("Mon titre", style="MonTitre") + p(BODY))
    assert heads(res.model) == [("Mon titre", 2, "outline_level")]


def test_direct_outline_level_on_normal_paragraph(make):
    res, _ = make(p("Titre via pPr", outline=2) + p(BODY))
    assert heads(res.model) == [("Titre via pPr", 3, "outline_level")]


def test_formatting_only_headings_ranked_by_prominence(make):
    body = (p("RAPPORT D'ACTIVITÉ", bold=True, size=16) + p(BODY) + p(BODY)
            + p("Résultats financiers", bold=True, size=13) + p(BODY) + p(BODY)
            + p("Chiffre d'affaires", bold=True) + p(BODY)
            + p("Résultats sociaux", bold=True, size=13) + p(BODY))
    res, _ = make(body)
    h = heads(res.model)
    assert [(t, l) for t, l, _ in h] == [("RAPPORT D'ACTIVITÉ", 1), ("Résultats financiers", 2),
                                         ("Chiffre d'affaires", 3), ("Résultats sociaux", 2)]
    assert all(s == "formatting" for *_, s in h)


def test_bold_sentence_is_not_a_heading(make):
    res, _ = make(p(BODY) + p("Attention, ce point est essentiel.", bold=True) + p(BODY)
                  + p("Un avertissement très long en gras " * 12, bold=True) + p(BODY))
    assert heads(res.model) == []


def test_share_guard_all_bold_document(make):
    body = "".join(p(f"Ligne courte {i}", bold=True) + p(BODY, bold=True) for i in range(12))
    res, _ = make(body)
    assert heads(res.model) == []


def test_consecutive_bold_block_is_not_headings(make):
    block = "".join(p(f"Nom {i}", bold=True) for i in range(5))
    res, _ = make(p(BODY) + block + p(BODY))
    assert heads(res.model) == []


def test_text_numbering_depth(make):
    res, _ = make(p("1. Introduction", bold=True) + p(BODY) + p("1.1 Contexte", bold=True) + p(BODY)
                  + p("1.1.1 Historique", bold=True) + p(BODY) + p("2. Méthode", bold=True) + p(BODY))
    assert [(t, l) for t, l, _ in heads(res.model)] == [("1. Introduction", 1), ("1.1 Contexte", 2),
                                                        ("1.1.1 Historique", 3), ("2. Méthode", 1)]


def test_numbered_plain_lines_are_not_headings(make):
    res, _ = make(p(BODY) + p("1. Acheter du pain") + p("2. Payer le loyer") + p(BODY))
    assert heads(res.model) == []
    assert [t.text for t in texts(res.model, "list_item")] == ["Acheter du pain", "Payer le loyer"]


def test_multilevel_word_numbering_headings(make):
    res, _ = make(p("Généralités", num=3, ilvl=0, bold=True) + p(BODY)
                  + p("Portée", num=3, ilvl=1, bold=True) + p(BODY))
    h = heads(res.model)
    assert [(t, l) for t, l, _ in h] == [("1. Généralités", 1), ("1.1. Portée", 2)]
    sec = [t for t in res.model.texts if t.text.endswith("Portée")][0]
    assert sec.meta["number"] == "1.1"


def test_formatting_levels_calibrated_on_explicit_headings(make):
    res, _ = make(p("Partie", style="Heading1") + p(BODY) + p("Pseudo-titre", bold=True, size=14) + p(BODY)
                  + p("Petit intertitre", bold=True) + p(BODY))
    got = {t: l for t, l, _ in heads(res.model)}
    assert got["Partie"] == 1 and got["Pseudo-titre"] == 2 and got["Petit intertitre"] >= 2


def test_style_keyword_heading(make):
    res, _ = make(p("Premier chapitre", style="TitreChapitre") + p(BODY))
    assert heads(res.model)[0][:2] == ("Premier chapitre", 1)


def test_headings_not_detected_in_tables(make):
    from docxbuilder import tbl, tc, tr
    res, _ = make(p(BODY) + tbl(tr(tc("Colonne", bold=True), tc("Valeur", bold=True)), tr(tc("a"), tc("b"))) + p(BODY))
    assert heads(res.model) == []
