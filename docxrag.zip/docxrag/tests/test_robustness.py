"""Robustesse : fichiers invalides, parties manquantes, styles cycliques, documents vides."""
import zipfile

import pytest
from docxbuilder import build_docx, p
from docxrag import DocxParser, parse_docx, to_docling_dict
from docxrag.ooxml import PackageError


def test_binary_doc_renamed_raises_package_error(tmp_path):
    f = tmp_path / "ancien.docx"
    f.write_bytes(b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1" + b"\0" * 512)   # signature OLE2 (.doc)
    with pytest.raises(PackageError):
        parse_docx(str(f))


def test_corrupted_zip(tmp_path):
    f = tmp_path / "casse.docx"
    f.write_bytes(b"PK\x03\x04garbage")
    with pytest.raises(PackageError):
        parse_docx(str(f))


def test_missing_styles_and_numbering(make):
    res, _ = make(p("Paragraphe seul."), styles=None, numbering=None)
    assert [t.text for t in res.model.texts] == ["Paragraphe seul."]


def test_basedon_cycle_does_not_hang(make):
    W = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"'
    styles = (f'<w:styles {W}><w:style w:type="paragraph" w:styleId="A"><w:name w:val="A"/><w:basedOn w:val="B"/>'
              '</w:style><w:style w:type="paragraph" w:styleId="B"><w:name w:val="B"/><w:basedOn w:val="A"/>'
              '</w:style></w:styles>')
    res, _ = make(p("Texte", style="A"), styles=styles)
    assert res.model.texts[0].text == "Texte"


def test_empty_document_is_valid_docling(make):
    pytest.importorskip("docling_core")
    from docling_core.types.doc import DoclingDocument
    res, _ = make("")
    assert res.model.texts == []
    DoclingDocument.model_validate(to_docling_dict(res.model))


def test_unknown_style_reference(make):
    res, _ = make(p("Texte", style="StyleInexistant"))
    assert res.model.texts[0].label == "text"


def test_case_insensitive_part_names(tmp_path):
    src = build_docx(p("Bonjour"))
    out = tmp_path / "casse.docx"
    with zipfile.ZipFile(__import__("io").BytesIO(src)) as zin, zipfile.ZipFile(out, "w") as zout:
        for item in zin.infolist():
            name = item.filename.replace("word/document.xml", "word/Document.xml")
            zout.writestr(name, zin.read(item.filename))
    assert DocxParser().parse(str(out)).model.texts[0].text == "Bonjour"


def test_streaming_and_dom_modes_agree(make):
    from docxrag import ParserConfig
    body = p("T", style="Heading1") + "".join(p(f"Paragraphe {i}") for i in range(50))
    a, path = make(body)
    b = parse_docx(path, ParserConfig(streaming=False))
    assert to_docling_dict(a.model) == to_docling_dict(b.model)
