"""Listes, tableaux, sommaire, légendes, images, zones de texte, révisions, champs, mobilier."""
from conftest import texts
from docxbuilder import (drawing, field_runs, p, png_bytes, run, tbl, tc, textbox_alternate, tr)
from docxrag import ParserConfig
from docxrag.model import GroupItem, PictureItem, TableItem

BODY = "Paragraphe de corps de texte suffisamment long pour servir de référence de taille."


# ------------------------------------------------------------------ listes
def test_lists_markers_nesting_and_restart(make):
    res, _ = make(p("Un", num=2) + p("sous a", num=2, ilvl=1) + p("sous b", num=2, ilvl=1) + p("Deux", num=2)
                  + p(BODY) + p("Reprise", num=4) + p(BODY) + p("Puce", num=1))
    items = texts(res.model, "list_item")
    assert [(i.marker, i.text) for i in items] == [("1.", "Un"), ("a)", "sous a"), ("b)", "sous b"),
                                                   ("2.", "Deux"), ("1.", "Reprise"), ("•", "Puce")]
    groups = [g for g in res.model.groups if g.name == "list"]
    nested = [g for g in groups if g.parent.startswith("#/texts")]
    assert len(nested) == 1 and res.model.resolve(nested[0].parent).text == "Un"


def test_manual_bullets_from_doc_conversion(make):
    res, _ = make(p(BODY) + p("\u2022\tPremier point") + p("-\tSecond point") + p("a) Option A") + p(BODY))
    items = texts(res.model, "list_item")
    assert [i.text for i in items] == ["Premier point", "Second point", "Option A"]
    assert items[0].meta["manual_list"] is True


# ---------------------------------------------------------------- tableaux
def test_table_merges_header_and_spans(make):
    t = tbl(tr(tc("Région", bold=True), tc("T1", bold=True), tc("T2", bold=True), header=True),
            tr(tc("Nord", vmerge="restart"), tc("10"), tc("20")),
            tr(tc("", vmerge="continue"), tc("11"), tc("21")),
            tr(tc("Total", span=2), tc("62")), cols=3)
    res, _ = make(p(BODY) + t)
    tab = res.model.tables[0]
    assert (tab.num_rows, tab.num_cols) == (4, 3)
    cells = {(c.start_row, c.start_col): c for c in tab.cells}
    assert cells[(1, 0)].row_span == 2 and cells[(1, 0)].text == "Nord"
    assert (2, 0) not in cells                             # pas de cellule fantôme dupliquée
    assert cells[(3, 0)].col_span == 2 and cells[(3, 2)].text == "62"
    assert all(c.column_header for c in tab.cells if c.start_row == 0)
    assert tab.meta["header_source"] == "tblHeader"


def test_hmerge_legacy_and_gridbefore(make):
    row = ('<w:tr><w:trPr><w:gridBefore w:val="1"/></w:trPr>' + tc("x") + tc("y") + "</w:tr>")
    t = tbl(tr(tc("A", hmerge="restart"), tc("", hmerge="continue"), tc("B")), row, cols=3)
    res, _ = make(t)
    cells = {(c.start_row, c.start_col): c for c in res.model.tables[0].cells}
    assert cells[(0, 0)].col_span == 2 and cells[(0, 2)].text == "B"
    assert cells[(1, 1)].text == "x" and (1, 0) not in cells


def test_nested_table_and_layout_table_unwrap(make):
    inner = tbl(tr(tc("i1"), tc("i2")))
    outer = tbl(tr(tc("Clé"), tc(inner=p("avant") + inner)), tr(tc("k"), tc("v")))
    layout = tbl(tr(tc(inner=p("Titre encadré", style="Heading1") + p(BODY))), cols=1)
    res, _ = make(outer + layout)
    m = res.model
    top = [t for t in m.tables if not t.meta.get("nested_in_cell")]
    assert len(top) == 1 and "i1 | i2" in [c for c in top[0].cells if c.start_col == 1][0].text
    assert any(t.meta.get("nested_in_cell") == [0, 1] for t in m.tables)
    assert [t.text for t in texts(m, "section_header")] == ["Titre encadré"]   # cadre 1x1 déballé


def test_bold_first_row_header_heuristic(make):
    res, _ = make(tbl(tr(tc("Nom", bold=True), tc("Âge", bold=True)), tr(tc("Ana"), tc("31"))))
    tab = res.model.tables[0]
    assert tab.meta["header_source"] == "bold_first_row"


# ----------------------------------------------------------------- sommaire
def toc_sdt(entries):
    rows = "".join(
        p(style=f"TOC{lvl}", runs=f'<w:hyperlink w:anchor="{anchor}">{run(text)}{run(extra="<w:tab/>")}{run(page)}</w:hyperlink>')
        for text, lvl, anchor, page in entries)
    return ('<w:sdt><w:sdtPr><w:docPartObj><w:docPartGallery w:val="Table of Contents"/></w:docPartObj></w:sdtPr>'
            f'<w:sdtContent>{p("Table des matières", style="TOCHeading")}{rows}</w:sdtContent></w:sdt>')


def bm(name, text, **kw):
    return p(runs=f'<w:bookmarkStart w:id="1" w:name="{name}"/>{run(text, **kw)}<w:bookmarkEnd w:id="1"/>')


def test_toc_sdt_excluded_from_body_and_linked(make):
    body = toc_sdt([("Introduction", 1, "_Toc1", "3"), ("Contexte", 2, "_Toc2", "4")]) \
        + p("Introduction", style="Heading1", runs=None) + p(BODY) + bm("_Toc2", "Contexte") + p(BODY)
    res, _ = make(body)
    m = res.model
    body_texts = [t.text for t in texts(m)]
    assert body_texts.count("Introduction") == 1 and "Table des matières" not in body_texts
    toc = [g for g in m.groups if g.name == "table_of_contents"][0]
    assert toc.content_layer == "furniture"
    entries = [m.resolve(r) for r in toc.children if m.resolve(r).label == "list_item"]
    assert [(e.text, e.meta["toc_level"], e.meta["page"]) for e in entries] == [("Introduction", 1, "3"), ("Contexte", 2, "4")]
    # « Contexte » n'a aucun style de titre : promu grâce à l'ancre du sommaire
    ctx = [t for t in m.texts if t.text == "Contexte" and t.content_layer == "body"][0]
    assert ctx.label == "section_header" and ctx.level == 2 and ctx.meta["heading_source"] == "toc_anchor"
    assert entries[1].meta["target_ref"] == ctx.self_ref


def test_toc_complex_field_spanning_paragraphs(make):
    first = p(style="TOC1", runs=field_runs('TOC \\o "1-3" \\h \\z \\u', run("Partie A") + run(extra="<w:tab/>") + run("2")).replace(
        '<w:r><w:fldChar w:fldCharType="end"/></w:r>', ""))
    second = p(runs=run("Partie B") + run(extra="<w:tab/>") + run("5") + '<w:r><w:fldChar w:fldCharType="end"/></w:r>')
    res, _ = make(first + second + p("Partie A", style="Heading1") + p(BODY) + p("Partie B", style="Heading1") + p(BODY))
    toc = [g for g in res.model.groups if g.name == "table_of_contents"][0]
    assert len(toc.children) == 2
    assert [t.text for t in texts(res.model)].count("Partie B") == 1


def test_plain_text_toc_with_dot_leaders(make):
    body = (p("Sommaire") + p("1. Objet ............ 3") + p("2. Périmètre ........ 5") + p("3. Annexes ....... 9")
            + p("1. Objet", bold=True) + p(BODY) + p("2. Périmètre") + p(BODY))
    res, _ = make(body)
    m = res.model
    assert "Sommaire" not in [t.text for t in texts(m)]
    h = {t.text: t.meta["heading_source"] for t in texts(m, "section_header")}
    # L'entrée de sommaire est prioritaire (règle d) sur la numérotation saisie (règle f) ;
    # « 2. Périmètre », non emphasé, n'est reconnu QUE grâce au sommaire.
    assert h["1. Objet"] in {"toc_text", "text_numbering"} and h["2. Périmètre"] == "toc_text"


# ----------------------------------------------------------- images/légendes
def test_image_metadata_caption_and_location(make):
    body = (p("Section", style="Heading1") + p(BODY)
            + p(runs=run(extra=drawing("rIdA", name="Schéma 1", descr="Architecture cible", cx=1905000, cy=952500)))
            + p(style="Caption", runs=run("Figure ") + field_runs("SEQ Figure \\* ARABIC", run("1")) + run(" : architecture")))
    res, _ = make(body, media={"rIdA": ("image1.png", png_bytes(400, 200))})
    pic = res.model.pictures[0]
    assert pic.meta["alt_text"] == "Architecture cible" and pic.meta["heading_path"] == ["Section"]
    assert pic.image["mimetype"] == "image/png" and pic.image["pixel_size"] == {"width": 400.0, "height": 200.0}
    assert pic.image["display_size_px"] == {"width": 200.0, "height": 100.0}
    assert len(pic.image["sha256"]) == 64 and pic.meta["part"] == "word/media/image1.png"
    cap = res.model.resolve(pic.captions[0])
    assert cap.text == "Figure 1 : architecture" and cap.meta["seq"] == "figure"
    assert [t.text for t in texts(res.model)].count("Figure 1 : architecture") == 1


def test_table_caption_above_and_figure_caption_by_regex(make):
    t = tbl(tr(tc("a"), tc("b")), tr(tc("1"), tc("2")))
    body = (p("Tableau 2 – Effectifs") + t + p(BODY)
            + p(runs=run(extra=drawing("rIdB"))) + p("Figure 3 : courbe"))
    res, _ = make(body, media={"rIdB": ("i.png", png_bytes())})
    assert res.model.resolve(res.model.tables[0].captions[0]).text == "Tableau 2 – Effectifs"
    assert res.model.resolve(res.model.pictures[0].captions[0]).text == "Figure 3 : courbe"


def test_same_image_twice_single_binary(make, tmp_path):
    img = p(runs=run(extra=drawing("rIdL")))
    cfg = ParserConfig(image_mode="export", image_export_dir=str(tmp_path / "img"))
    res, _ = make(img + p(BODY) + img, cfg=cfg, media={"rIdL": ("logo.png", png_bytes(50, 50))})
    pics = res.model.pictures
    assert len(pics) == 2 and pics[0].image["sha256"] == pics[1].image["sha256"]
    assert len(list((tmp_path / "img").iterdir())) == 1
    assert res.model.meta["image_occurrences"][pics[0].image["sha256"]] == 2


def test_vml_image_from_doc_conversion_and_anchor_position(make):
    vml = ('<w:pict><v:shape id="_x0000_i1025" style="width:150pt;height:75pt">'
           '<v:imagedata r:id="rIdV" o:title="Ancien schéma"/></v:shape></w:pict>')
    res, _ = make(p(runs=run(extra=vml)) + p(runs=run(extra=drawing("rIdV", anchor=True))),
                  media={"rIdV": ("v.png", png_bytes())})
    vpic, apic = res.model.pictures
    assert vpic.meta["placement"] == "vml" and vpic.meta["alt_text"] == "Ancien schéma"
    assert vpic.image["display_size_px"]["width"] == 200.0
    assert apic.meta["placement"] == "anchor" and apic.meta["position"]["positionH"]["relative_from"] == "column"


def test_image_in_table_cell(make):
    t = tbl(tr(tc("Logo"), tc(inner=p(runs=run(extra=drawing("rIdC"))))))
    res, _ = make(t, media={"rIdC": ("c.png", png_bytes())})
    pic = res.model.pictures[0]
    assert pic.parent == res.model.tables[0].self_ref and pic.meta["cell"] == [0, 1]


def test_chart_reference_keeps_cached_values(make):
    chart_xml = (b'<c:chartSpace xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" '
                 b'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><c:chart><c:title><c:tx><c:rich>'
                 b'<a:p><a:r><a:t>Ventes 2025</a:t></a:r></a:p></c:rich></c:tx></c:title>'
                 b'<c:plotArea><c:ser><c:val><c:numRef><c:numCache><c:pt idx="0"><c:v>42</c:v></c:pt>'
                 b'</c:numCache></c:numRef></c:val></c:ser></c:plotArea></c:chart></c:chartSpace>')
    drawing_chart = ('<w:drawing><wp:inline><wp:extent cx="100" cy="100"/><wp:docPr id="5" name="Graphique 1"/>'
                     '<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/chart">'
                     '<c:chart r:id="rIdCh"/></a:graphicData></a:graphic></wp:inline></w:drawing>')
    res, _ = make(p(runs=run(extra=drawing_chart)), extra_parts={"rIdCh": ("charts/chart1.xml", "chart", chart_xml)})
    pic = res.model.pictures[0]
    assert pic.label == "chart" and "Ventes 2025" in pic.meta["chart_text"] and "42" in pic.meta["chart_text"]


# ------------------------------------------------------ doublons classiques
def test_textbox_alternate_content_read_once(make):
    res, _ = make(p(runs=run("Ancre") + textbox_alternate(p("Texte encadré unique"))) + p(BODY))
    all_text = [t.text for t in texts(res.model)]
    assert all_text.count("Texte encadré unique") == 1
    tb = [t for t in res.model.texts if t.text == "Texte encadré unique"][0]
    assert tb.meta["in_textbox"] is True


def test_tracked_changes_and_field_instructions(make):
    runs = (run("Le montant est de ") + '<w:del w:id="1"><w:r><w:delText>100</w:delText></w:r></w:del>'
            + '<w:ins w:id="2"><w:r><w:t>120</w:t></w:r></w:ins>' + run(" euros, voir page ")
            + field_runs("PAGEREF _Ref123 \\h", run("7")) + run("."))
    res, _ = make(p(runs=runs))
    assert texts(res.model)[0].text == "Le montant est de 120 euros, voir page 7."


def test_hidden_text_and_sdt_placeholder(make):
    sdt = ('<w:sdt><w:sdtPr><w:showingPlcHdr/><w:text/></w:sdtPr><w:sdtContent>'
           + run("Valeur saisie") + "</w:sdtContent></w:sdt>")
    hidden = '<w:r><w:rPr><w:vanish/></w:rPr><w:t>secret</w:t></w:r>'
    res, _ = make(p(runs=run("Champ : ") + sdt + hidden))
    assert texts(res.model)[0].text == "Champ : Valeur saisie"


# ----------------------------------------------------------------- mobilier
HDR = {"rIdH1": p("En-tête confidentiel", style="Header")}
FTR = {"rIdF1": p(runs=run("Page ") + field_runs("PAGE", run("1")))}


def test_headers_footers_excluded_by_default(make):
    res, _ = make(p(BODY), headers=HDR, footers=FTR)
    assert res.model.furniture.children == []
    assert all("confidentiel" not in t.text for t in res.model.texts)


def test_headers_footers_optional_and_deduplicated(make):
    hdrs = {"rIdH1": HDR["rIdH1"], "rIdH2": HDR["rIdH1"]}      # même en-tête sur 2 sections
    res, _ = make(p(BODY), cfg=ParserConfig(include_furniture=True), headers=hdrs, footers=FTR)
    fur = [res.model.resolve(r) for r in res.model.furniture.children]
    assert [(f.label, f.text) for f in fur] == [("page_header", "En-tête confidentiel"), ("page_footer", "Page 1")]


def test_repeated_page_lines_injected_in_body(make):
    pb = p(runs='<w:r><w:br w:type="page"/></w:r>')
    body = "".join(p(BODY) + p("Société X – Rapport 2025") + p(f"Page {i} sur 3") + pb for i in range(1, 4))
    res, _ = make(body)
    body_texts = [t.text for t in texts(res.model)]
    assert not any(t.startswith("Page ") for t in body_texts)
    assert "Société X – Rapport 2025" not in body_texts
    # 3 sauts de page, le dernier en fin de document : 3 pages de contenu.
    assert res.model.meta["approx_pages"] == 3


def test_footnotes_attached_to_paragraph(make):
    ref = '<w:r><w:footnoteReference w:id="1"/></w:r>'
    res, _ = make(p(runs=run("Affirmation sourcée") + ref) + p(runs=run("Rappel") + ref),
                  footnotes={"1": "Source : INSEE 2024."})
    notes = texts(res.model, "footnote")
    assert len(notes) == 1 and notes[0].text == "Source : INSEE 2024."
    assert res.model.resolve(notes[0].parent).text == "Affirmation sourcée"


def test_math_paragraph_is_formula(make):
    omml = '<m:oMathPara><m:oMath><m:r><m:t>E=mc²</m:t></m:r></m:oMath></m:oMathPara>'
    res, _ = make(f"<w:p>{omml}</w:p>")
    assert texts(res.model, "formula")[0].text == "E=mc²"
