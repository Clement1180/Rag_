"""Fabrique de DOCX minimalistes en XML brut : contrôle total des cas limites
(styles non standards, champs, révisions, AlternateContent, VML…)."""
from __future__ import annotations

import io
import zipfile
from xml.sax.saxutils import escape

NSDECL = ('xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
          'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
          'xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" '
          'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
          'xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture" '
          'xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" '
          'xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" '
          'xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" '
          'xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math" '
          'xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" '
          'mc:Ignorable="w14 wp14"')


def run(text="", bold=False, size=None, caps=False, italic=False, extra=""):
    rpr = ""
    if bold:
        rpr += "<w:b/>"
    if italic:
        rpr += "<w:i/>"
    if caps:
        rpr += "<w:caps/>"
    if size:
        rpr += f'<w:sz w:val="{int(size * 2)}"/>'
    rpr = f"<w:rPr>{rpr}</w:rPr>" if rpr else ""
    t = f'<w:t xml:space="preserve">{escape(text)}</w:t>' if text else ""
    return f"<w:r>{rpr}{t}{extra}</w:r>"


def p(text="", style=None, bold=False, size=None, caps=False, italic=False, num=None, ilvl=0,
      outline=None, jc=None, ppr_extra="", runs=None, ind=None):
    ppr = ""
    if style:
        ppr += f'<w:pStyle w:val="{style}"/>'
    if num is not None:
        ppr += f'<w:numPr><w:ilvl w:val="{ilvl}"/><w:numId w:val="{num}"/></w:numPr>'
    if ind is not None:
        ppr += f'<w:ind w:left="{ind}"/>'
    if jc:
        ppr += f'<w:jc w:val="{jc}"/>'
    if outline is not None:
        ppr += f'<w:outlineLvl w:val="{outline}"/>'
    ppr += ppr_extra
    body = runs if runs is not None else (run(text, bold, size, caps, italic) if text else "")
    return f"<w:p>{'<w:pPr>' + ppr + '</w:pPr>' if ppr else ''}{body}</w:p>"


def drawing(rid, name="Image 1", descr="", cx=1905000, cy=952500, pid=1, anchor=False):
    tag = "anchor" if anchor else "inline"
    extra = ('<wp:positionH relativeFrom="column"><wp:posOffset>12700</wp:posOffset></wp:positionH>'
             '<wp:positionV relativeFrom="paragraph"><wp:posOffset>0</wp:posOffset></wp:positionV>'
             ) if anchor else ""
    wrap = '<wp:wrapSquare wrapText="bothSides"/>' if anchor else ""
    return (f'<w:drawing><wp:{tag}>{extra}<wp:extent cx="{cx}" cy="{cy}"/>{wrap}'
            f'<wp:docPr id="{pid}" name="{name}" descr="{escape(descr)}"/>'
            '<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">'
            f'<pic:pic><pic:blipFill><a:blip r:embed="{rid}"/></pic:blipFill></pic:pic>'
            f'</a:graphicData></a:graphic></wp:{tag}></w:drawing>')


def textbox_alternate(inner_paragraphs: str) -> str:
    """Zone de texte telle que Word l'écrit : Choice (wps) + Fallback (VML) = contenu en double."""
    return ('<w:r><mc:AlternateContent><mc:Choice Requires="wps"><w:drawing><wp:anchor>'
            '<wp:extent cx="1000" cy="1000"/><wp:docPr id="99" name="Zone de texte 1"/>'
            '<a:graphic><a:graphicData uri="http://schemas.microsoft.com/office/word/2010/wordprocessingShape">'
            f'<wps:wsp><wps:txbx><w:txbxContent>{inner_paragraphs}</w:txbxContent></wps:txbx></wps:wsp>'
            '</a:graphicData></a:graphic></wp:anchor></w:drawing></mc:Choice>'
            f'<mc:Fallback><w:pict><v:shape><v:textbox><w:txbxContent>{inner_paragraphs}</w:txbxContent>'
            '</v:textbox></v:shape></w:pict></mc:Fallback></mc:AlternateContent></w:r>')


def field_runs(instr: str, result_runs: str) -> str:
    return (f'<w:r><w:fldChar w:fldCharType="begin"/></w:r><w:r><w:instrText xml:space="preserve">'
            f' {escape(instr)} </w:instrText></w:r><w:r><w:fldChar w:fldCharType="separate"/></w:r>'
            f'{result_runs}<w:r><w:fldChar w:fldCharType="end"/></w:r>')


def tc(text="", span=1, vmerge=None, hmerge=None, bold=False, inner=None):
    pr = ""
    if span > 1:
        pr += f'<w:gridSpan w:val="{span}"/>'
    if vmerge is not None:
        pr += '<w:vMerge w:val="restart"/>' if vmerge == "restart" else "<w:vMerge/>"
    if hmerge is not None:
        pr += '<w:hMerge w:val="restart"/>' if hmerge == "restart" else "<w:hMerge/>"
    content = inner if inner is not None else p(text, bold=bold)
    return f"<w:tc>{'<w:tcPr>' + pr + '</w:tcPr>' if pr else ''}{content}</w:tc>"


def tr(*cells, header=False):
    trpr = "<w:trPr><w:tblHeader/></w:trPr>" if header else ""
    return f"<w:tr>{trpr}{''.join(cells)}</w:tr>"


def tbl(*rows, cols=2, style=None):
    grid = "".join('<w:gridCol w:w="2000"/>' for _ in range(cols))
    st = f'<w:tblStyle w:val="{style}"/>' if style else ""
    pr = f"<w:tblPr>{st}</w:tblPr>"
    return f"<w:tbl>{pr}<w:tblGrid>{grid}</w:tblGrid>{''.join(rows)}</w:tbl>"


STYLES = """<w:styles %s>
<w:docDefaults><w:rPrDefault><w:rPr><w:sz w:val="22"/></w:rPr></w:rPrDefault></w:docDefaults>
<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/></w:style>
<w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:basedOn w:val="Normal"/><w:rPr><w:sz w:val="56"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:basedOn w:val="Normal"/><w:pPr><w:outlineLvl w:val="0"/></w:pPr><w:rPr><w:b/><w:sz w:val="32"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/><w:basedOn w:val="Normal"/><w:pPr><w:outlineLvl w:val="1"/></w:pPr><w:rPr><w:b/><w:sz w:val="28"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Level1"><w:name w:val="Level 1"/><w:basedOn w:val="Normal"/><w:rPr><w:b/><w:sz w:val="28"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Level2"><w:name w:val="Level 2"/><w:basedOn w:val="Normal"/><w:rPr><w:b/><w:sz w:val="24"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="MonTitre"><w:name w:val="Mon Titre Maison"/><w:basedOn w:val="Heading2"/></w:style>
<w:style w:type="paragraph" w:styleId="TitreChapitre"><w:name w:val="Titre Chapitre"/><w:basedOn w:val="Normal"/><w:rPr><w:b/><w:sz w:val="36"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Caption"><w:name w:val="caption"/><w:basedOn w:val="Normal"/><w:rPr><w:i/><w:sz w:val="18"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="TOC1"><w:name w:val="toc 1"/><w:basedOn w:val="Normal"/></w:style>
<w:style w:type="paragraph" w:styleId="TOC2"><w:name w:val="toc 2"/><w:basedOn w:val="Normal"/></w:style>
<w:style w:type="paragraph" w:styleId="TOCHeading"><w:name w:val="TOC Heading"/><w:basedOn w:val="Heading1"/></w:style>
<w:style w:type="paragraph" w:styleId="ListParagraph"><w:name w:val="List Paragraph"/><w:basedOn w:val="Normal"/></w:style>
<w:style w:type="paragraph" w:styleId="Header"><w:name w:val="header"/><w:basedOn w:val="Normal"/></w:style>
</w:styles>""" % NSDECL

NUMBERING = """<w:numbering %s>
<w:abstractNum w:abstractNumId="1">
 <w:lvl w:ilvl="0"><w:start w:val="1"/><w:numFmt w:val="bullet"/><w:lvlText w:val="\uf0b7"/></w:lvl>
 <w:lvl w:ilvl="1"><w:start w:val="1"/><w:numFmt w:val="bullet"/><w:lvlText w:val="o"/></w:lvl>
</w:abstractNum>
<w:abstractNum w:abstractNumId="2">
 <w:lvl w:ilvl="0"><w:start w:val="1"/><w:numFmt w:val="decimal"/><w:lvlText w:val="%%1."/></w:lvl>
 <w:lvl w:ilvl="1"><w:start w:val="1"/><w:numFmt w:val="lowerLetter"/><w:lvlText w:val="%%2)"/></w:lvl>
</w:abstractNum>
<w:abstractNum w:abstractNumId="3">
 <w:lvl w:ilvl="0"><w:start w:val="1"/><w:numFmt w:val="decimal"/><w:lvlText w:val="%%1."/></w:lvl>
 <w:lvl w:ilvl="1"><w:start w:val="1"/><w:numFmt w:val="decimal"/><w:lvlText w:val="%%1.%%2."/></w:lvl>
 <w:lvl w:ilvl="2"><w:start w:val="1"/><w:numFmt w:val="decimal"/><w:lvlText w:val="%%1.%%2.%%3."/></w:lvl>
</w:abstractNum>
<w:num w:numId="1"><w:abstractNumId w:val="1"/></w:num>
<w:num w:numId="2"><w:abstractNumId w:val="2"/></w:num>
<w:num w:numId="3"><w:abstractNumId w:val="3"/></w:num>
<w:num w:numId="4"><w:abstractNumId w:val="2"/><w:lvlOverride w:ilvl="0"><w:startOverride w:val="1"/></w:lvlOverride></w:num>
</w:numbering>""" % NSDECL


def png_bytes(w=200, h=100, color=(200, 30, 30)) -> bytes:
    from PIL import Image
    buf = io.BytesIO()
    Image.new("RGB", (w, h), color).save(buf, "PNG")
    return buf.getvalue()


def build_docx(body: str, *, styles: str | None = STYLES, numbering: str | None = NUMBERING,
               media: dict[str, tuple[str, bytes]] | None = None, footnotes: dict[str, str] | None = None,
               headers: dict[str, str] | None = None, footers: dict[str, str] | None = None,
               sectpr: bool = True, extra_parts: dict[str, tuple[str, str, bytes]] | None = None) -> bytes:
    """media : rId -> (nom de fichier, octets). headers/footers : rId -> xml de paragraphes."""
    media, headers, footers, extra_parts = media or {}, headers or {}, footers or {}, extra_parts or {}
    rels = []
    ct_over = ['<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>']
    files: dict[str, bytes] = {}
    R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    if styles:
        rels.append(f'<Relationship Id="rIdStyles" Type="{R}/styles" Target="styles.xml"/>')
        files["word/styles.xml"] = styles.encode()
    if numbering:
        rels.append(f'<Relationship Id="rIdNum" Type="{R}/numbering" Target="numbering.xml"/>')
        files["word/numbering.xml"] = numbering.encode()
    for rid, (fname, data) in media.items():
        rels.append(f'<Relationship Id="{rid}" Type="{R}/image" Target="media/{fname}"/>')
        files[f"word/media/{fname}"] = data
    if footnotes:
        rels.append(f'<Relationship Id="rIdFn" Type="{R}/footnotes" Target="footnotes.xml"/>')
        fx = "".join(f'<w:footnote w:id="{k}">{p(v)}</w:footnote>' for k, v in footnotes.items())
        files["word/footnotes.xml"] = (f'<w:footnotes {NSDECL}><w:footnote w:type="separator" w:id="-1">'
                                       f'<w:p><w:r><w:separator/></w:r></w:p></w:footnote>{fx}</w:footnotes>').encode()
    hdr_refs = ""
    for i, (rid, xml) in enumerate(headers.items()):
        rels.append(f'<Relationship Id="{rid}" Type="{R}/header" Target="header{i+1}.xml"/>')
        files[f"word/header{i+1}.xml"] = f"<w:hdr {NSDECL}>{xml}</w:hdr>".encode()
        hdr_refs += f'<w:headerReference w:type="default" r:id="{rid}"/>'
    for i, (rid, xml) in enumerate(footers.items()):
        rels.append(f'<Relationship Id="{rid}" Type="{R}/footer" Target="footer{i+1}.xml"/>')
        files[f"word/footer{i+1}.xml"] = f"<w:ftr {NSDECL}>{xml}</w:ftr>".encode()
        hdr_refs += f'<w:footerReference w:type="default" r:id="{rid}"/>'
    for rid, (target, rtype, data) in extra_parts.items():
        rels.append(f'<Relationship Id="{rid}" Type="{R}/{rtype}" Target="{target}"/>')
        files[f"word/{target}"] = data
    sect = f"<w:sectPr>{hdr_refs}</w:sectPr>" if sectpr else ""
    files["word/document.xml"] = f'<w:document {NSDECL}><w:body>{body}{sect}</w:body></w:document>'.encode()
    files["word/_rels/document.xml.rels"] = (
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        + "".join(rels) + "</Relationships>").encode()
    files["_rels/.rels"] = (
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        f'<Relationship Id="rId1" Type="{R}/officeDocument" Target="word/document.xml"/></Relationships>').encode()
    files["[Content_Types].xml"] = (
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        '<Default Extension="png" ContentType="image/png"/><Default Extension="emf" ContentType="image/x-emf"/>'
        + "".join(ct_over) + "</Types>").encode()
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for name, data in files.items():
            z.writestr(name, data)
    return buf.getvalue()
