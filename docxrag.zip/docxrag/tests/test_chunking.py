"""Chunking : frontières de sections, budget, tableaux découpés, dédoublonnage, fil d'Ariane."""
from docxbuilder import p, tbl, tr, tc
from docxrag import ChunkerConfig, chunk_document

LONG = ("Le prestataire assure la maintenance corrective et évolutive du système. " * 6).strip()


def test_sections_are_chunk_boundaries(make):
    body = (p("Contexte", style="Level1") + p(LONG) + p("Objectifs", style="Level1") + p(LONG))
    res, _ = make(body)
    chunks = chunk_document(res.model, ChunkerConfig(max_tokens=200, min_tokens=10))
    assert [c.heading_path for c in chunks] == [["Contexte"], ["Objectifs"]]
    # le titre n'est pas dupliqué : il apparaît dans le fil d'Ariane, pas deux fois
    assert chunks[0].embed_text.count("Contexte") == 1


def test_budget_respected_and_split_on_sentences(make):
    # paragraphes distincts (des paragraphes identiques seraient dédoublonnés)
    res, _ = make(p("Titre", style="Heading1") + "".join(p(f"Lot {i}. " + LONG) for i in range(8)))
    cfg = ChunkerConfig(max_tokens=120, min_tokens=10)
    chunks = chunk_document(res.model, cfg)
    assert len(chunks) > 3
    assert all(c.token_count <= cfg.max_tokens for c in chunks)
    assert all(c.text.rstrip().endswith(".") for c in chunks)      # coupure en fin de phrase
    assert all(c.heading_path == ["Titre"] for c in chunks)
    assert chunks[0].meta["next"] == chunks[1].chunk_id and chunks[1].meta["prev"] == chunks[0].chunk_id


def test_small_sections_are_merged(make):
    body = p("A", style="Heading1") + p("Court.") + p("B", style="Heading1") + p("Court aussi.")
    res, _ = make(body)
    chunks = chunk_document(res.model, ChunkerConfig(max_tokens=300, min_tokens=80))
    assert len(chunks) == 1


def test_large_table_split_with_repeated_header(make):
    rows = [tr(tc("Code", bold=True), tc("Libellé", bold=True), header=True)]
    rows += [tr(tc(f"C{i:03d}"), tc(f"Libellé détaillé numéro {i} pour la ligne")) for i in range(60)]
    res, _ = make(p("Référentiel", style="Heading1") + tbl(*rows))
    chunks = [c for c in chunk_document(res.model, ChunkerConfig(max_tokens=150, min_tokens=10))
              if c.kind == "table"]
    assert len(chunks) > 2
    assert all("| Code | Libellé |" in c.text for c in chunks)       # en-tête répété dans chaque morceau
    joined = "\n".join(c.text for c in chunks)
    assert all(f"C{i:03d}" in joined for i in range(60))             # aucune ligne perdue
    assert "lignes" in chunks[0].embed_text                           # « (lignes X-Y / N) »


def test_identical_chunks_deduplicated(make):
    boiler = "Document confidentiel, diffusion restreinte aux destinataires de la présente note. " * 3
    body = (p("A", style="Heading1") + p(boiler) + p("B", style="Heading1") + p(boiler))
    res, _ = make(body)
    chunks = chunk_document(res.model, ChunkerConfig(max_tokens=200, min_tokens=5, merge_small_sections=False))
    hashes = [c.content_hash for c in chunks]
    assert len(hashes) == len(set(hashes))


def test_toc_never_chunked(make):
    body = (p("Introduction ........ 3", style="TOC1") + p("Introduction", style="Heading1") + p(LONG))
    res, _ = make(body)
    chunks = chunk_document(res.model, ChunkerConfig(min_tokens=5))
    assert all("........" not in c.text for c in chunks)
