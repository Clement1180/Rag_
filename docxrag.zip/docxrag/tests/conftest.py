import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from docxbuilder import build_docx  # noqa: E402
from docxrag import ParserConfig, parse_docx  # noqa: E402


@pytest.fixture
def make(tmp_path):
    counter = {"n": 0}

    def _make(body: str, cfg: ParserConfig | None = None, **kw):
        counter["n"] += 1
        path = tmp_path / f"doc{counter['n']}.docx"
        path.write_bytes(build_docx(body, **kw))
        return parse_docx(str(path), cfg), str(path)
    return _make


def texts(model, label=None, layers=frozenset({"body"})):
    return [it for it, _ in model.iterate(layers=layers)
            if hasattr(it, "text") and (label is None or it.label == label)]
