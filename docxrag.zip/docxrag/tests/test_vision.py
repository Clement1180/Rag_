"""Enrichissement multimodal : désactivé par défaut, un appel par binaire, cache, erreurs isolées."""
import threading

from docxbuilder import drawing, p, png_bytes, run
from docxrag.vision import CallableDescriber, DescriptionCache, VisionConfig, enrich_pictures


def _doc(make, n_same=1):
    img = "".join(p(runs=run(extra=drawing("rIdI", pid=i + 1))) + p(f"Figure {i + 1} : schéma") for i in range(n_same))
    body = p("Titre", style="Heading1") + p("Texte avant.") + img
    return make(body, media={"rIdI": ("i.png", png_bytes(300, 200))})


def test_disabled_by_default(make):
    (res, path) = _doc(make)
    calls = []
    stats = enrich_pictures(res.model, path, CallableDescriber(lambda i: calls.append(1) or "x"),
                            VisionConfig())
    assert calls == [] and stats["described"] == 0
    assert res.model.pictures[0].description is None


def test_one_call_per_unique_binary_and_context(make):
    res, path = _doc(make, n_same=2)
    seen, lock = [], threading.Lock()

    def fake(inp):
        with lock:
            seen.append(inp)
        return "Schéma d'architecture"
    stats = enrich_pictures(res.model, path, CallableDescriber(fake, id="fake:v1"), VisionConfig(enabled=True))
    assert len(seen) == 1 and stats["described"] == 2
    assert seen[0].context.heading_path == ("Titre",) and "Figure" in seen[0].context.caption
    assert "Texte avant" in seen[0].context.neighbor_text
    assert all(pic.description["text"] == "Schéma d'architecture" for pic in res.model.pictures)


def test_cache_prevents_second_call(make, tmp_path):
    res, path = _doc(make)
    cache = DescriptionCache(str(tmp_path / "cache.jsonl"))
    d = CallableDescriber(lambda i: "desc", id="fake:v1")
    enrich_pictures(res.model, path, d, VisionConfig(enabled=True), cache)
    res2, _ = _doc(make)
    boom = CallableDescriber(lambda i: (_ for _ in ()).throw(AssertionError("pas d'appel attendu")), id="fake:v1")
    stats = enrich_pictures(res2.model, path, boom, VisionConfig(enabled=True),
                            DescriptionCache(str(tmp_path / "cache.jsonl")))
    assert stats["cached"] == 1 and res2.model.pictures[0].description["text"] == "desc"


def test_provider_error_does_not_break_parsing(make):
    res, path = _doc(make)
    def fail(_):
        raise RuntimeError("quota")
    stats = enrich_pictures(res.model, path, CallableDescriber(fail), VisionConfig(enabled=True))
    assert stats["errors"] == 1 and res.model.pictures[0].description is None


def test_repeated_logo_and_tiny_images_skipped(make):
    body = "".join(p(runs=run(extra=drawing("rIdL", pid=i))) for i in range(1, 4)) \
        + p(runs=run(extra=drawing("rIdT", pid=9, cx=9525 * 10, cy=9525 * 10)))
    res, path = make(body, media={"rIdL": ("l.png", png_bytes(300, 200)), "rIdT": ("t.png", png_bytes(10, 10))})
    stats = enrich_pictures(res.model, path, CallableDescriber(lambda i: "x"), VisionConfig(enabled=True))
    assert stats["described"] == 0 and stats["skipped"] == 4
