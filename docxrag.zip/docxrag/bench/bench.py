"""Micro-benchmark : docxrag (streaming / DOM) vs python-docx (texte brut seulement).

Usage : python bench/bench.py [nb_sections]
"""
import sys
import time
import tracemalloc
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "tests")]

from docxbuilder import build_docx, drawing, p, png_bytes, run, tbl, tc, tr  # noqa: E402
from docxrag import ChunkerConfig, ParserConfig, chunk_document, parse_docx, to_docling_dict  # noqa: E402

N = int(sys.argv[1]) if len(sys.argv) > 1 else 300
TXT = "Le titulaire met en œuvre les moyens nécessaires à la continuité du service. " * 4


def make_doc(path: Path) -> None:
    parts = []
    for s in range(N):
        parts.append(p(f"Chapitre {s + 1}", style="Level1"))
        for k in range(3):
            parts.append(p(f"{s + 1}.{k + 1} Sous-partie", bold=True, size=26))
            parts += [p(TXT) for _ in range(4)]
            parts += [p(f"Point {j}", num=1) for j in range(3)]
        if s % 5 == 0:
            parts.append(p(f"Tableau {s + 1} : indicateurs"))
            parts.append(tbl(tr(tc("Indicateur", bold=True), tc("Valeur", bold=True), header=True),
                             *[tr(tc(f"I{i}"), tc(str(i * 3))) for i in range(20)]))
        if s % 10 == 0:
            parts.append(p(runs=run(extra=drawing("rIdImg", pid=s + 1))) + p(f"Figure {s + 1} : schéma"))
    path.write_bytes(build_docx("".join(parts), media={"rIdImg": ("img.png", png_bytes(400, 300))}))


def timed(label, fn, repeat=3):
    best = float("inf")
    for _ in range(repeat):                      # temps mesuré SANS tracemalloc (qui ralentit ×2)
        t = time.perf_counter()
        out = fn()
        best = min(best, time.perf_counter() - t)
    tracemalloc.start()
    fn()
    peak = tracemalloc.get_traced_memory()[1]
    tracemalloc.stop()
    print(f"{label:<42} {best * 1000:9.1f} ms   pic mémoire {peak / 2**20:7.1f} Mo")
    return out


if __name__ == "__main__":
    f = Path("/tmp/bench.docx")
    make_doc(f)
    import zipfile
    xml_mb = zipfile.ZipFile(f).getinfo("word/document.xml").file_size / 2**20
    print(f"Document : {f.stat().st_size / 1024:.0f} Ko zippé, document.xml {xml_mb:.1f} Mo, {N} chapitres")
    res = timed("docxrag parse (streaming)", lambda: parse_docx(str(f)))
    timed("docxrag parse (DOM complet)", lambda: parse_docx(str(f), ParserConfig(streaming=False)))
    timed("docxrag parse + JSON Docling", lambda: to_docling_dict(parse_docx(str(f)).model))
    ch = timed("docxrag chunking seul", lambda: chunk_document(res.model, ChunkerConfig()))
    print(f"\n  étapes : {res.timings_ms}")
    print(f"  items : {len(res.model.texts)} textes, {len(res.model.tables)} tableaux, "
          f"{len(res.model.pictures)} images ; {len(ch)} chunks")
    chars = sum(len(t.text) for t in res.model.texts)
    print(f"  {chars:,} caractères ≈ {chars / 2000:.0f} pages équivalentes (2 000 car./page)")
    print(f"  sources de titres : {res.model.meta['heading_sources']}\n")
    try:
        import docx

        def pd():
            d = docx.Document(str(f))
            return [x.text for x in d.paragraphs] + [c.text for t in d.tables for r in t.rows for c in r.cells]
        timed("python-docx (texte brut, sans structure)", pd)
    except ImportError:
        pass
